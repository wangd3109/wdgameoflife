from setuptools import setup

setup(name='wdgameoflife',
        version='0.0.3',
        description='This is a project for the course Advanced Scientific Programming in Python - Uppsala University',
        url='https://github.com/wangd3109/wdgameoflife',
        author='Duo Wang',
        author_email='wangd3109@gmail.com',
        license='MIT',
        packages=['wdgameoflife'],
        zip_safe=False)

